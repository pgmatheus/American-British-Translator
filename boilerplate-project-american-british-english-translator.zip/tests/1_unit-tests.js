const chai = require('chai');
const assert = chai.assert;

const Translator = require('../components/translator.js');
let translator = new Translator();

suite('Unit Tests', () => {
  suite('tests', () =>{

    test('Translate Mangoes are my favorite fruit.',function(done) {
      let string = 'Mangoes are my favorite fruit.';
      let local = 'american-to-british'
      assert.equal(translator.transl(string,local),'Mangoes are my <span class="highlight">favourite</span> fruit.');
      done();
    })

    test('I ate yogurt for breakfast.',function(done) {
      let string = 'I ate yogurt for breakfast.';
      let local = 'american-to-british'
      assert.equal(translator.transl(string,local),'I ate <span class="highlight">yoghurt</span> for breakfast.');
      done();
    })

    test("We had a party at my friend's condo.",function(done) {
      let string = "We had a party at my friend's condo.";
      let local = 'american-to-british'
      assert.equal(translator.transl(string,local),'We had a party at my friend'+"'s "+ '<span class="highlight">flat.</span>');
      done();
    })

    test('Can you toss this in the trashcan for me?',function(done) {
      let string = 'Can you toss this in the trashcan for me?';
      let local = 'american-to-british'
      assert.equal(translator.transl(string,local),'Can you toss this in the <span class="highlight">bin</span> for me?');
      done();
    })

    test('The parking lot was full.',function(done) {
      let string = 'The parking lot was full.';
      let local = 'american-to-british'
      assert.equal(translator.transl(string,local),'The <span class="highlight">car park</span> was full.');
      done();
    })

    test('Translate Like a high tech Rube Goldberg machine.',function(done) {
      let string = 'Like a high tech Rube Goldberg machine.';
      let local = 'american-to-british'
      assert.equal(translator.transl(string,local),'Like a high tech <span class="highlight">Heath Robinson device</span>.');
      done();
    })

    test('Translate To play hooky means to skip class or work.',function(done) {
      let string = 'To play hooky means to skip class or work.';
      let local = 'american-to-british'
      assert.equal(translator.transl(string,local),'To <span class="highlight">bunk off</span> means to skip class or work.');
      done();
    })    

    test('Translate No Mr. Bond, I expect you to die.',function(done) {
      let string = 'No Mr. Bond, I expect you to die.';
      let local = 'american-to-british'
      assert.equal(translator.transl(string,local),'No <span class="highlight">Mr</span> Bond, I expect you to die.');
      done();
    })

    test('Translate Dr. Grosh will see you now.', function(done) {
      let string = 'Dr. Grosh will see you now.';
      let local = 'american-to-british'
      assert.equal(translator.transl(string,local),'<span class="highlight">Dr</span> Grosh will see you now.');
      done();
    })

    test('Translate Lunch is at 12:15 today.', function(done) {
      let string = 'Lunch is at 12:15 today.';
      let local = 'american-to-british'
      assert.equal(translator.transl(string,local),'Lunch is at <span class="highlight">12.15</span> today.');
      done();
    })    

    test('Translate We watched the footie match for a while.', function(done) {
      let string = 'We watched the footie match for a while.';
      let local = 'british-to-american'
      assert.equal(translator.transl(string,local),'We watched the <span class="highlight">soccer</span> match for a while.');
      done();
    })

    test('Translate Paracetamol takes up to an hour to work.', function(done) {
      let string = 'Paracetamol takes up to an hour to work.';
      let local = 'british-to-american'
      assert.equal(translator.transl(string,local),'<span class="highlight">Tylenol</span> takes up to an hour to work.');
      done();
    })

    test('First, caramelise the onions.', function(done) {
      let string = 'First, caramelise the onions.';
      let local = 'british-to-american'
      assert.equal(translator.transl(string,local),'First, <span class="highlight">caramelize</span> the onions.');
      done();
    })

    test('I spent the bank holiday at the funfair.', function(done) {
      let string = 'I spent the bank holiday at the funfair.';
      let local = 'british-to-american'
      assert.equal(translator.transl(string,local),'I spent the <span class="highlight">public holiday</span> at the <span class="highlight">carnival.</span>');
      done();
    })

    test('I had a bicky then went to the chippy.', function(done) {
      let string = 'I had a bicky then went to the chippy.';
      let local = 'british-to-american'
      assert.equal(translator.transl(string,local),'I had a <span class="highlight">cookie</span> then went to the <span class="highlight">fish-and-chip shop.</span>');
      done();
    })

    test("I've just got bits and bobs in my bum bag.", function(done) {
      let string = "I've just got bits and bobs in my bum bag.";
      let local = 'british-to-american'
      assert.equal(translator.transl(string,local),"I've just got "+ '<span class="highlight">odds and ends</span> in my <span class="highlight">fanny pack</span>.');
      done();
    })

    test('The car boot sale at Boxted Airfield was called off.', function(done) {
      let string = 'The car boot sale at Boxted Airfield was called off.';
      let local = 'british-to-american'
      assert.equal(translator.transl(string,local),'The <span class="highlight">swap meet</span> at Boxted Airfield was called off.');
      done();
    })

    test('Have you met Mrs Kalyani?', function(done) {
      let string = 'Have you met Mrs Kalyani?';
      let local = 'british-to-american'
      assert.equal(translator.transl(string,local),'Have you met <span class="highlight">Mrs.</span> Kalyani?');
      done();
    })    

    test("Prof Joyner of King's College, London.", function(done) {
      let string = "Prof Joyner of King's College, London.";
      let local = 'british-to-american'
      assert.equal(translator.transl(string,local),'<span class="highlight">Prof.</span> Joyner of King'+"'s College, London.");
      done();
    })    

    test('Tea time is usually around 4 or 4.30.', function(done) {
      let string = 'Tea time is usually around 4 or 4.30.';
      let local = 'british-to-american'
      assert.equal(translator.transl(string,local),'Tea time is usually around 4 or <span class="highlight">4:30.</span>');
      done();
    })    

    test('Highlight translation in Mangoes are my favorite fruit.',function(done) {
      let string = 'Mangoes are my favorite fruit.';
      let local = 'american-to-british'
      assert.equal(translator.transl(string,local),'Mangoes are my <span class="highlight">favourite</span> fruit.');
      done();
    })

    test('Highlight translation in I ate yogurt for breakfast.',function(done) {
      let string = 'I ate yogurt for breakfast.';
      let local = 'american-to-british'
      assert.equal(translator.transl(string,local),'I ate <span class="highlight">yoghurt</span> for breakfast.');
      done();
    })

    test('Highlight translation in Translate We watched the footie match for a while.', function(done) {
      let string = 'We watched the footie match for a while.';
      let local = 'british-to-american'
      assert.equal(translator.transl(string,local),'We watched the <span class="highlight">soccer</span> match for a while.');
      done();
    })

    test('Highlight translation in Translate Paracetamol takes up to an hour to work.', function(done) {
      let string = 'Paracetamol takes up to an hour to work.';
      let local = 'british-to-american'
      assert.equal(translator.transl(string,local),'<span class="highlight">Tylenol</span> takes up to an hour to work.');
      done();
    })

  })
});
