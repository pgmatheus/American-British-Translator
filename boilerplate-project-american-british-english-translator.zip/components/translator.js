const americanOnly = require('./american-only.js');
const americanToBritishSpelling = require('./american-to-british-spelling.js');
const americanToBritishTitles = require("./american-to-british-titles.js")
const britishOnly = require('./british-only.js')

class Translator {
  transl(text,locale) {
    let words = text.split(' ');
    let trad = [];
    if (locale == 'british-to-american'){
      trad = Object.entries({...americanToBritishSpelling, ...americanToBritishTitles});
      trad = trad.concat(britishOnly[0]);
      for (let i = 0;i<trad.length;i++){
        trad[i] = [trad[i][1],trad[i][0]];
      }
    }
    else{
      trad = Object.entries({...americanOnly, ...americanToBritishSpelling, ...americanToBritishTitles});
    }
    let b = search(words,trad,locale)
    return b
  }
}

module.exports = Translator;

function search(words,trad,locale) {
  let mod = false;
  let tempw = '';
  let sstr = ''; 
  let regex = /^([0-9]{1,2})([:]{1})([0-9]{1,2}$)/;
  let sub1 = '.';
  let sub2 = ':'
  if (locale == 'british-to-american'){
    regex = /^([0-9]{1,2})([.]{1})([0-9]{1,2}$)/;
    sub1 = ':';
    sub2 = '.';
  }
  let upcase = [];
  let old = false;


  for (let i = 0; i< words.length;i++){
    upcase[i] = [0,0]
    if (words[i].match(/^[A-Z]/)){
      upcase[i][0] = 1;
      words[i] = words[i].charAt(0).toLowerCase().concat(words[i].substring(1,words[i].length));
    }
    if (words[i].match(/\.$/)){
      words[i] = words[i].slice(0,-1);
      upcase[i][1] = 1;
    }
  }

 
  for (let i = 0; i<words.length; i++){

    for (let j = 0; j<trad.length; j++){      
      if (i + 2 < words.length && mod == false){
        tempw = merge(words,i,2);
        tempw = tempw.slice(1,tempw.length);

        if (tempw == trad[j][0]) {
          sstr = sstr.concat(dotupper(trad[j][1], upcase[i],old));
        if (upcase[i+2][1] == 1){
          sstr = dtplus(sstr);
        }          
          
          mod = true;
          i = i + 2;
        }
      }      
    }

    for (let j = 0; j<trad.length; j++){      
      if (i + 1 < words.length && mod == false){
        tempw = merge(words,i,1);
        tempw = tempw.slice(1,tempw.length);

        if (tempw == trad[j][0]) {
          sstr = sstr.concat(dotupper(trad[j][1], upcase[i],old));
        if (upcase[i+1][1] == 1){
          sstr = dtplus(sstr);
        }          
          
          mod = true;
          i++;
        }
      }      
    }

    for (let j = 0; j<trad.length; j++){      
        if (words[i] == trad[j][0] && mod == false) {
          sstr = sstr.concat(dotupper(trad[j][1], upcase[i],old))
          mod = true;
        }
        else if (words[i].concat('.') == trad[j][0] && mod == false) {
          upcase[i][1] = 0;
          sstr = sstr.concat(dotupper(trad[j][1], upcase[i],old));
          mod = true;
        }
      }
    
    if (words[i].match(regex) != null && mod == false) {
      // sstr = sstr.concat('<span class="highlight">', words[i].replace(sub2,sub1),'</span> ');
      sstr = sstr.concat(dotupper(words[i].replace(sub2,sub1), upcase[i],old))
      mod = true;
    }

    if (mod == true){
      mod = false;
    }
    else{

      old = true;
      sstr = sstr.concat(dotupper(words[i], upcase[i],old));
      old = false;
    }

    
  }
    
  sstr = sstr.slice(0,-1);
  return(sstr);
    
  }

function merge (words,k,l){
  // let tempw = words[k];
  let tempw = ''
  // for (let i = k+1;i<k+l;i++){
  for (let i = k;i<=k+l;i++){
    tempw = tempw.concat(' ', words[i]);
  }
  return tempw
}

function dotupper(trad, upcase, old,a,b){
  if (upcase[0] == 1){
    trad = trad.charAt(0).toUpperCase().concat(trad.slice(1,trad.length));
  }
  if (upcase[1] == 1){
    trad = trad.concat('.');
  }
  if (old == false){
    return '<span class="highlight">'+ trad + '</span> ' 
  }
  else{
    return trad + ' '
  }
}

function dtplus(sstr){
  sstr = sstr.slice(0,-1)
  sstr = sstr.concat('. ');
  return sstr
}